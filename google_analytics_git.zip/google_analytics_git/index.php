<?php
require_once('autoload.php');
require_once 'GoogleAnalyticsServiceHandler.php';

$client_email = 'xxxxxxxxxxxxxxxxxxxxxxxxxxx.gserviceaccount.com';
$key_file = 'path_to_key_file/file.p12';

$ga_handler = new GoogleAnalyticsServiceHandler($client_email,$key_file);
$ga_handler->set_profile_id('ga:xxxxxxx');



$ga_handler->set_analytics_start_date('2017-08-23');
$ga_handler->set_analytics_end_date('2017-08-24');
$data2 = $ga_handler->get_dimensional_analytics('ga:pagePath,ga:channelGrouping');
$products = $data2->rows;
$webPropertyId  = $data2->modelData['profileInfo']['webPropertyId'];
print_r($products);

